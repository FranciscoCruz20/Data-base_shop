-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: 2023bd_g10
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `pedido`
--

DROP TABLE IF EXISTS `pedido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pedido` (
  `idPedido` int NOT NULL,
  `dataPedido` datetime DEFAULT NULL,
  `dataEntrega` datetime DEFAULT NULL,
  `estado` varchar(45) DEFAULT NULL,
  `envio` varchar(45) DEFAULT NULL,
  `Cliente_idCliente` int NOT NULL,
  `Entrega_idEntrega` int DEFAULT NULL,
  `ValoresEntrega_idValoresEntrega` int DEFAULT NULL,
  `DespesaEntrega_idDespesaEntrega` int DEFAULT NULL,
  PRIMARY KEY (`idPedido`),
  KEY `fk_Pedido_Cliente_idx` (`Cliente_idCliente`),
  KEY `fk_Pedido_Entrega1_idx` (`Entrega_idEntrega`),
  KEY `fk_Pedido_ValoresEntrega1_idx` (`ValoresEntrega_idValoresEntrega`),
  KEY `fk_Pedido_DespesaEntrega1_idx` (`DespesaEntrega_idDespesaEntrega`),
  CONSTRAINT `fk_Pedido_Cliente` FOREIGN KEY (`Cliente_idCliente`) REFERENCES `cliente` (`idCliente`),
  CONSTRAINT `fk_Pedido_DespesaEntrega1` FOREIGN KEY (`DespesaEntrega_idDespesaEntrega`) REFERENCES `despesaentrega` (`idDespesaEntrega`),
  CONSTRAINT `fk_Pedido_Entrega1` FOREIGN KEY (`Entrega_idEntrega`) REFERENCES `entrega` (`idEntrega`),
  CONSTRAINT `fk_Pedido_ValoresEntrega1` FOREIGN KEY (`ValoresEntrega_idValoresEntrega`) REFERENCES `valoresentrega` (`idValoresEntrega`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pedido`
--

LOCK TABLES `pedido` WRITE;
/*!40000 ALTER TABLE `pedido` DISABLE KEYS */;
INSERT INTO `pedido` VALUES (1,'2023-04-23 00:00:00','2023-05-10 00:00:00','Iniciado','normal',1,1,1,NULL),(2,'2023-03-23 00:00:00','2023-05-20 00:00:00','Iniciado','normal',2,2,1,NULL),(3,'2022-05-05 00:00:00','2022-05-05 00:00:00','Entregue','normal',3,3,2,NULL),(4,'2021-05-05 00:00:00','2021-05-05 00:00:00','Entregue','normal',3,4,2,NULL),(5,'2020-06-03 00:00:00','2020-06-03 00:00:00','Entregue','normal',3,5,1,NULL),(6,'2023-05-26 00:00:00','2023-05-26 00:00:00','Iniciado','normal',4,6,2,NULL);
/*!40000 ALTER TABLE `pedido` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-28  4:46:06
