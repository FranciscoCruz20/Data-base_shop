-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: 2023bd_g10
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `bestseller122`
--

DROP TABLE IF EXISTS `bestseller122`;
/*!50001 DROP VIEW IF EXISTS `bestseller122`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `bestseller122` AS SELECT 
 1 AS `Produto`,
 1 AS `Cliente`,
 1 AS `Data_Pedido`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `bestseller3`
--

DROP TABLE IF EXISTS `bestseller3`;
/*!50001 DROP VIEW IF EXISTS `bestseller3`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `bestseller3` AS SELECT 
 1 AS `Produto`,
 1 AS `Cliente`,
 1 AS `Data_Pedido`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `testetrigger`
--

DROP TABLE IF EXISTS `testetrigger`;
/*!50001 DROP VIEW IF EXISTS `testetrigger`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `testetrigger` AS SELECT 
 1 AS `idProduto`,
 1 AS `quantidadeStock`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `bestseller22`
--

DROP TABLE IF EXISTS `bestseller22`;
/*!50001 DROP VIEW IF EXISTS `bestseller22`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `bestseller22` AS SELECT 
 1 AS `Produto`,
 1 AS `Cliente`,
 1 AS `Data_Pedido`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `bestseller5`
--

DROP TABLE IF EXISTS `bestseller5`;
/*!50001 DROP VIEW IF EXISTS `bestseller5`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `bestseller5` AS SELECT 
 1 AS `Produto`,
 1 AS `Cliente`,
 1 AS `Data_Pedido`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `pedidosmesano`
--

DROP TABLE IF EXISTS `pedidosmesano`;
/*!50001 DROP VIEW IF EXISTS `pedidosmesano`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `pedidosmesano` AS SELECT 
 1 AS `year`,
 1 AS `month`,
 1 AS `quantidade`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `bestseller1222`
--

DROP TABLE IF EXISTS `bestseller1222`;
/*!50001 DROP VIEW IF EXISTS `bestseller1222`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `bestseller1222` AS SELECT 
 1 AS `Produto`,
 1 AS `Cliente`,
 1 AS `Data_Pedido`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `pedidoatualizadoview12345`
--

DROP TABLE IF EXISTS `pedidoatualizadoview12345`;
/*!50001 DROP VIEW IF EXISTS `pedidoatualizadoview12345`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `pedidoatualizadoview12345` AS SELECT 
 1 AS `idPedido`,
 1 AS `ValorTotal`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `lastseller`
--

DROP TABLE IF EXISTS `lastseller`;
/*!50001 DROP VIEW IF EXISTS `lastseller`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `lastseller` AS SELECT 
 1 AS `idProduto`,
 1 AS `nome`,
 1 AS `descricao`,
 1 AS `total_vendido`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `pedidoatualizadoview1234567`
--

DROP TABLE IF EXISTS `pedidoatualizadoview1234567`;
/*!50001 DROP VIEW IF EXISTS `pedidoatualizadoview1234567`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `pedidoatualizadoview1234567` AS SELECT 
 1 AS `idPedido`,
 1 AS `Produto`,
 1 AS `ValorTotal`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `testetrigger1`
--

DROP TABLE IF EXISTS `testetrigger1`;
/*!50001 DROP VIEW IF EXISTS `testetrigger1`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `testetrigger1` AS SELECT 
 1 AS `idProduto`,
 1 AS `quantidadeStock`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `pedidoatualizadoview12345678`
--

DROP TABLE IF EXISTS `pedidoatualizadoview12345678`;
/*!50001 DROP VIEW IF EXISTS `pedidoatualizadoview12345678`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `pedidoatualizadoview12345678` AS SELECT 
 1 AS `idPedido`,
 1 AS `Cliente`,
 1 AS `ValorTotal`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `testetrigger21`
--

DROP TABLE IF EXISTS `testetrigger21`;
/*!50001 DROP VIEW IF EXISTS `testetrigger21`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `testetrigger21` AS SELECT 
 1 AS `idProduto`,
 1 AS `quantidadeStock`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `pedidosaoano21`
--

DROP TABLE IF EXISTS `pedidosaoano21`;
/*!50001 DROP VIEW IF EXISTS `pedidosaoano21`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `pedidosaoano21` AS SELECT 
 1 AS `Ano`,
 1 AS `Vendas`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `lastseller12345`
--

DROP TABLE IF EXISTS `lastseller12345`;
/*!50001 DROP VIEW IF EXISTS `lastseller12345`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `lastseller12345` AS SELECT 
 1 AS `Produto`,
 1 AS `Vendas`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `bestseller11222`
--

DROP TABLE IF EXISTS `bestseller11222`;
/*!50001 DROP VIEW IF EXISTS `bestseller11222`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `bestseller11222` AS SELECT 
 1 AS `Produto`,
 1 AS `Cliente`,
 1 AS `Data_Pedido`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `pedidoatualizado122111`
--

DROP TABLE IF EXISTS `pedidoatualizado122111`;
/*!50001 DROP VIEW IF EXISTS `pedidoatualizado122111`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `pedidoatualizado122111` AS SELECT 
 1 AS `idPedido`,
 1 AS `valor_anterior`,
 1 AS `Produto_Remover`,
 1 AS `novo_valor`,
 1 AS `Produto`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `pedidosaoano1`
--

DROP TABLE IF EXISTS `pedidosaoano1`;
/*!50001 DROP VIEW IF EXISTS `pedidosaoano1`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `pedidosaoano1` AS SELECT 
 1 AS `year`,
 1 AS `quantidade`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `testetrigger2`
--

DROP TABLE IF EXISTS `testetrigger2`;
/*!50001 DROP VIEW IF EXISTS `testetrigger2`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `testetrigger2` AS SELECT 
 1 AS `idProduto`,
 1 AS `quantidadeStock`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `bestseller111`
--

DROP TABLE IF EXISTS `bestseller111`;
/*!50001 DROP VIEW IF EXISTS `bestseller111`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `bestseller111` AS SELECT 
 1 AS `Produto`,
 1 AS `Cliente`,
 1 AS `Data_Pedido`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `pedidosmesano1`
--

DROP TABLE IF EXISTS `pedidosmesano1`;
/*!50001 DROP VIEW IF EXISTS `pedidosmesano1`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `pedidosmesano1` AS SELECT 
 1 AS `Ano`,
 1 AS `Mês`,
 1 AS `Vendas`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `bestseller2`
--

DROP TABLE IF EXISTS `bestseller2`;
/*!50001 DROP VIEW IF EXISTS `bestseller2`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `bestseller2` AS SELECT 
 1 AS `Produto`,
 1 AS `Cliente`,
 1 AS `Data_Pedido`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `pedidoatualizadoview123`
--

DROP TABLE IF EXISTS `pedidoatualizadoview123`;
/*!50001 DROP VIEW IF EXISTS `pedidoatualizadoview123`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `pedidoatualizadoview123` AS SELECT 
 1 AS `idPedido`,
 1 AS `ValorTotal`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `bestseller11`
--

DROP TABLE IF EXISTS `bestseller11`;
/*!50001 DROP VIEW IF EXISTS `bestseller11`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `bestseller11` AS SELECT 
 1 AS `Produto`,
 1 AS `Cliente`,
 1 AS `Data_Pedido`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `bestseller1122`
--

DROP TABLE IF EXISTS `bestseller1122`;
/*!50001 DROP VIEW IF EXISTS `bestseller1122`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `bestseller1122` AS SELECT 
 1 AS `Produto`,
 1 AS `Cliente`,
 1 AS `Data_Pedido`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `bestseller112`
--

DROP TABLE IF EXISTS `bestseller112`;
/*!50001 DROP VIEW IF EXISTS `bestseller112`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `bestseller112` AS SELECT 
 1 AS `Produto`,
 1 AS `Cliente`,
 1 AS `Data_Pedido`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `pedidoatualizadoview123456`
--

DROP TABLE IF EXISTS `pedidoatualizadoview123456`;
/*!50001 DROP VIEW IF EXISTS `pedidoatualizadoview123456`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `pedidoatualizadoview123456` AS SELECT 
 1 AS `idPedido`,
 1 AS `Produto`,
 1 AS `ValorTotal`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `lastseller123`
--

DROP TABLE IF EXISTS `lastseller123`;
/*!50001 DROP VIEW IF EXISTS `lastseller123`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `lastseller123` AS SELECT 
 1 AS `idProduto`,
 1 AS `nome`,
 1 AS `descricao`,
 1 AS `total_vendido`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `pedidoatualizadoview1234`
--

DROP TABLE IF EXISTS `pedidoatualizadoview1234`;
/*!50001 DROP VIEW IF EXISTS `pedidoatualizadoview1234`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `pedidoatualizadoview1234` AS SELECT 
 1 AS `idPedido`,
 1 AS `ValorTotal`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `lastseller1234`
--

DROP TABLE IF EXISTS `lastseller1234`;
/*!50001 DROP VIEW IF EXISTS `lastseller1234`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `lastseller1234` AS SELECT 
 1 AS `nome`,
 1 AS `total_vendido`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `comprafalsa`
--

DROP TABLE IF EXISTS `comprafalsa`;
/*!50001 DROP VIEW IF EXISTS `comprafalsa`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `comprafalsa` AS SELECT 
 1 AS `idProduto`,
 1 AS `quantidadeStock`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `pedidosaoano`
--

DROP TABLE IF EXISTS `pedidosaoano`;
/*!50001 DROP VIEW IF EXISTS `pedidosaoano`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `pedidosaoano` AS SELECT 
 1 AS `year`,
 1 AS `quantidade`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `lastseller12`
--

DROP TABLE IF EXISTS `lastseller12`;
/*!50001 DROP VIEW IF EXISTS `lastseller12`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `lastseller12` AS SELECT 
 1 AS `idProduto`,
 1 AS `nome`,
 1 AS `descricao`,
 1 AS `total_vendido`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `lastseller1`
--

DROP TABLE IF EXISTS `lastseller1`;
/*!50001 DROP VIEW IF EXISTS `lastseller1`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `lastseller1` AS SELECT 
 1 AS `idProduto`,
 1 AS `nome`,
 1 AS `descricao`,
 1 AS `total_vendido`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `pedidosaoano2`
--

DROP TABLE IF EXISTS `pedidosaoano2`;
/*!50001 DROP VIEW IF EXISTS `pedidosaoano2`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `pedidosaoano2` AS SELECT 
 1 AS `Ano`,
 1 AS `quantidade`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `pedidosaoano22`
--

DROP TABLE IF EXISTS `pedidosaoano22`;
/*!50001 DROP VIEW IF EXISTS `pedidosaoano22`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `pedidosaoano22` AS SELECT 
 1 AS `Ano`,
 1 AS `Vendas`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `pedidoatualizado`
--

DROP TABLE IF EXISTS `pedidoatualizado`;
/*!50001 DROP VIEW IF EXISTS `pedidoatualizado`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `pedidoatualizado` AS SELECT 
 1 AS `idPedido`,
 1 AS `Cliente`,
 1 AS `ValorTotal`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `bestseller122`
--

/*!50001 DROP VIEW IF EXISTS `bestseller122`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `bestseller122` AS select `produto`.`nome` AS `Produto`,`cliente`.`nome` AS `Cliente`,`pedido`.`dataPedido` AS `Data_Pedido` from (((`produto` join `itempedido` on((`produto`.`idProduto` = `itempedido`.`Produto_idProduto`))) join `pedido` on((`itempedido`.`Pedido_idPedido` = `pedido`.`idPedido`))) join `cliente` on((`pedido`.`Cliente_idCliente` = `cliente`.`idCliente`))) where (`produto`.`idProduto` = (select `produto`.`idProduto` from `itempedido` group by `produto`.`idProduto` order by sum(`itempedido`.`quantidade`) desc limit 3)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `bestseller3`
--

/*!50001 DROP VIEW IF EXISTS `bestseller3`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `bestseller3` AS select `produto`.`nome` AS `Produto`,`cliente`.`nome` AS `Cliente`,`pedido`.`dataPedido` AS `Data_Pedido` from (((`produto` join `itempedido` on((`produto`.`idProduto` = `itempedido`.`Produto_idProduto`))) join `pedido` on((`itempedido`.`Pedido_idPedido` = `pedido`.`idPedido`))) join `cliente` on((`pedido`.`Cliente_idCliente` = `cliente`.`idCliente`))) where (`produto`.`idProduto` = (select `produto`.`idProduto` from `itempedido` group by `produto`.`idProduto` order by sum(`itempedido`.`quantidade`) desc limit 3)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `testetrigger`
--

/*!50001 DROP VIEW IF EXISTS `testetrigger`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `testetrigger` AS select `produto`.`idProduto` AS `idProduto`,`produto`.`quantidadeStock` AS `quantidadeStock` from `produto` limit 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `bestseller22`
--

/*!50001 DROP VIEW IF EXISTS `bestseller22`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `bestseller22` AS select `produto`.`nome` AS `Produto`,`cliente`.`nome` AS `Cliente`,`pedido`.`dataPedido` AS `Data_Pedido` from (((`produto` join `itempedido` on((`produto`.`idProduto` = `itempedido`.`Produto_idProduto`))) join `pedido` on((`itempedido`.`Pedido_idPedido` = `pedido`.`idPedido`))) join `cliente` on((`pedido`.`Cliente_idCliente` = `cliente`.`idCliente`))) where (`produto`.`idProduto` = (select `produto`.`idProduto` from `itempedido` group by `produto`.`idProduto` order by sum(`itempedido`.`quantidade`) desc)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `bestseller5`
--

/*!50001 DROP VIEW IF EXISTS `bestseller5`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `bestseller5` AS select `produto`.`nome` AS `Produto`,`cliente`.`nome` AS `Cliente`,`pedido`.`dataPedido` AS `Data_Pedido` from (((`produto` join `itempedido` on((`produto`.`idProduto` = `itempedido`.`Produto_idProduto`))) join `pedido` on((`itempedido`.`Pedido_idPedido` = `pedido`.`idPedido`))) join `cliente` on((`pedido`.`Cliente_idCliente` = `cliente`.`idCliente`))) where (`produto`.`idProduto` = (select `produto`.`idProduto` from `itempedido` group by `produto`.`idProduto` limit 3)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `pedidosmesano`
--

/*!50001 DROP VIEW IF EXISTS `pedidosmesano`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `pedidosmesano` AS select year(`pedido`.`dataPedido`) AS `year`,month(`pedido`.`dataPedido`) AS `month`,count(0) AS `quantidade` from `pedido` group by year(`pedido`.`dataPedido`),month(`pedido`.`dataPedido`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `bestseller1222`
--

/*!50001 DROP VIEW IF EXISTS `bestseller1222`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `bestseller1222` AS select `produto`.`nome` AS `Produto`,`cliente`.`nome` AS `Cliente`,`pedido`.`dataPedido` AS `Data_Pedido` from (((`produto` join `itempedido` on((`produto`.`idProduto` = `itempedido`.`Produto_idProduto`))) join `pedido` on((`itempedido`.`Pedido_idPedido` = `pedido`.`idPedido`))) join `cliente` on((`pedido`.`Cliente_idCliente` = `cliente`.`idCliente`))) where (`produto`.`idProduto` = (select `produto`.`idProduto` from `itempedido` group by `produto`.`idProduto` order by sum(`itempedido`.`quantidade`) desc limit 3)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `pedidoatualizadoview12345`
--

/*!50001 DROP VIEW IF EXISTS `pedidoatualizadoview12345`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `pedidoatualizadoview12345` AS select `pedido`.`idPedido` AS `idPedido`,sum((`itempedido`.`preco` * `itempedido`.`quantidade`)) AS `ValorTotal` from (`pedido` join (`itempedido` join `produto` on((`itempedido`.`Produto_idProduto` = `produto`.`idProduto`)))) where ((`pedido`.`idPedido` = 6) and (`itempedido`.`Pedido_idPedido` = `pedido`.`idPedido`)) limit 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `lastseller`
--

/*!50001 DROP VIEW IF EXISTS `lastseller`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `lastseller` AS select `produto`.`idProduto` AS `idProduto`,`produto`.`nome` AS `nome`,`produto`.`descricao` AS `descricao`,sum(`itempedido`.`quantidade`) AS `total_vendido` from ((`pedido` join `itempedido` on((`pedido`.`idPedido` = `itempedido`.`Pedido_idPedido`))) join `produto` on((`itempedido`.`Produto_idProduto` = `produto`.`idProduto`))) group by `produto`.`idProduto`,`produto`.`nome` order by max(`pedido`.`dataEntrega`) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `pedidoatualizadoview1234567`
--

/*!50001 DROP VIEW IF EXISTS `pedidoatualizadoview1234567`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `pedidoatualizadoview1234567` AS select `pedido`.`idPedido` AS `idPedido`,`produto`.`nome` AS `Produto`,sum((`itempedido`.`preco` * `itempedido`.`quantidade`)) AS `ValorTotal` from (`pedido` join (`itempedido` join `produto` on((`itempedido`.`Produto_idProduto` = `produto`.`idProduto`)))) where ((`pedido`.`idPedido` = 6) and (`itempedido`.`Pedido_idPedido` = `pedido`.`idPedido`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `testetrigger1`
--

/*!50001 DROP VIEW IF EXISTS `testetrigger1`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `testetrigger1` AS select `produto`.`idProduto` AS `idProduto`,`produto`.`quantidadeStock` AS `quantidadeStock` from `produto` limit 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `pedidoatualizadoview12345678`
--

/*!50001 DROP VIEW IF EXISTS `pedidoatualizadoview12345678`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `pedidoatualizadoview12345678` AS select `pedido`.`idPedido` AS `idPedido`,`cliente`.`nome` AS `Cliente`,sum((`itempedido`.`preco` * `itempedido`.`quantidade`)) AS `ValorTotal` from (((`itempedido` join `produto` on((`itempedido`.`Produto_idProduto` = `produto`.`idProduto`))) join `pedido` on((`itempedido`.`Pedido_idPedido` = `pedido`.`idPedido`))) join `cliente` on((`pedido`.`Cliente_idCliente` = `cliente`.`idCliente`))) where ((`pedido`.`idPedido` = 6) and (`itempedido`.`Pedido_idPedido` = `pedido`.`idPedido`) and (`pedido`.`Cliente_idCliente` = `cliente`.`idCliente`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `testetrigger21`
--

/*!50001 DROP VIEW IF EXISTS `testetrigger21`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `testetrigger21` AS select `produto`.`idProduto` AS `idProduto`,`produto`.`quantidadeStock` AS `quantidadeStock` from `produto` limit 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `pedidosaoano21`
--

/*!50001 DROP VIEW IF EXISTS `pedidosaoano21`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `pedidosaoano21` AS select year(`pedido`.`dataPedido`) AS `Ano`,count(0) AS `Vendas` from `pedido` group by year(`pedido`.`dataPedido`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `lastseller12345`
--

/*!50001 DROP VIEW IF EXISTS `lastseller12345`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `lastseller12345` AS select `produto`.`nome` AS `Produto`,sum(`itempedido`.`quantidade`) AS `Vendas` from ((`pedido` join `itempedido` on((`pedido`.`idPedido` = `itempedido`.`Pedido_idPedido`))) join `produto` on((`itempedido`.`Produto_idProduto` = `produto`.`idProduto`))) group by `produto`.`nome` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `bestseller11222`
--

/*!50001 DROP VIEW IF EXISTS `bestseller11222`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `bestseller11222` AS select `produto`.`nome` AS `Produto`,`cliente`.`nome` AS `Cliente`,`pedido`.`dataPedido` AS `Data_Pedido` from (((`produto` join `itempedido` on((`produto`.`idProduto` = `itempedido`.`Produto_idProduto`))) join `pedido` on((`itempedido`.`Pedido_idPedido` = `pedido`.`idPedido`))) join `cliente` on((`pedido`.`Cliente_idCliente` = `cliente`.`idCliente`))) where (`produto`.`idProduto` = (select `produto`.`idProduto` from `itempedido` group by `produto`.`idProduto` order by sum(`itempedido`.`quantidade`) desc)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `pedidoatualizado122111`
--

/*!50001 DROP VIEW IF EXISTS `pedidoatualizado122111`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `pedidoatualizado122111` AS select `pedido`.`idPedido` AS `idPedido`,sum((`itempedido`.`preco` * `itempedido`.`quantidade`)) AS `valor_anterior`,`produto`.`nome` AS `Produto_Remover`,(sum((`itempedido`.`preco` * `itempedido`.`quantidade`)) - (`itempedido`.`preco` * `itempedido`.`quantidade`)) AS `novo_valor`,`p`.`nome` AS `Produto` from (((`pedido` join `itempedido` on((`pedido`.`idPedido` = `itempedido`.`Pedido_idPedido`))) join `produto` on((`itempedido`.`Produto_idProduto` = `produto`.`idProduto`))) left join `produto` `p` on((`pedido`.`idPedido` = `itempedido`.`Pedido_idPedido`))) where ((`pedido`.`idPedido` = 1) and (`produto`.`idProduto` = 2)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `pedidosaoano1`
--

/*!50001 DROP VIEW IF EXISTS `pedidosaoano1`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `pedidosaoano1` AS select year(`pedido`.`dataPedido`) AS `year`,count(0) AS `quantidade` from `pedido` group by year(`pedido`.`dataPedido`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `testetrigger2`
--

/*!50001 DROP VIEW IF EXISTS `testetrigger2`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `testetrigger2` AS select `produto`.`idProduto` AS `idProduto`,`produto`.`quantidadeStock` AS `quantidadeStock` from `produto` limit 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `bestseller111`
--

/*!50001 DROP VIEW IF EXISTS `bestseller111`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `bestseller111` AS select `produto`.`nome` AS `Produto`,`cliente`.`nome` AS `Cliente`,`pedido`.`dataPedido` AS `Data_Pedido` from (((`produto` join `itempedido` on((`produto`.`idProduto` = `itempedido`.`Produto_idProduto`))) join `pedido` on((`itempedido`.`Pedido_idPedido` = `pedido`.`idPedido`))) join `cliente` on((`pedido`.`Cliente_idCliente` = `cliente`.`idCliente`))) where (`produto`.`idProduto` = (select `produto`.`idProduto` from `itempedido` group by `produto`.`idProduto`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `pedidosmesano1`
--

/*!50001 DROP VIEW IF EXISTS `pedidosmesano1`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `pedidosmesano1` AS select year(`pedido`.`dataPedido`) AS `Ano`,month(`pedido`.`dataPedido`) AS `Mês`,count(0) AS `Vendas` from `pedido` group by year(`pedido`.`dataPedido`),month(`pedido`.`dataPedido`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `bestseller2`
--

/*!50001 DROP VIEW IF EXISTS `bestseller2`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `bestseller2` AS select `produto`.`nome` AS `Produto`,`cliente`.`nome` AS `Cliente`,`pedido`.`dataPedido` AS `Data_Pedido` from (((`produto` join `itempedido` on((`produto`.`idProduto` = `itempedido`.`Produto_idProduto`))) join `pedido` on((`itempedido`.`Pedido_idPedido` = `pedido`.`idPedido`))) join `cliente` on((`pedido`.`Cliente_idCliente` = `cliente`.`idCliente`))) where (`produto`.`idProduto` = (select `produto`.`idProduto` from `itempedido` group by `produto`.`idProduto` order by sum(`itempedido`.`quantidade`) desc limit 3)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `pedidoatualizadoview123`
--

/*!50001 DROP VIEW IF EXISTS `pedidoatualizadoview123`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `pedidoatualizadoview123` AS select `pedido`.`idPedido` AS `idPedido`,sum((`itempedido`.`preco` * `itempedido`.`quantidade`)) AS `ValorTotal` from (`pedido` join (`itempedido` join `produto` on((`itempedido`.`Produto_idProduto` = `produto`.`idProduto`)))) where (`pedido`.`idPedido` = 1) limit 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `bestseller11`
--

/*!50001 DROP VIEW IF EXISTS `bestseller11`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `bestseller11` AS select `produto`.`nome` AS `Produto`,`cliente`.`nome` AS `Cliente`,`pedido`.`dataPedido` AS `Data_Pedido` from (((`produto` join `itempedido` on((`produto`.`idProduto` = `itempedido`.`Produto_idProduto`))) join `pedido` on((`itempedido`.`Pedido_idPedido` = `pedido`.`idPedido`))) join `cliente` on((`pedido`.`Cliente_idCliente` = `cliente`.`idCliente`))) where (`produto`.`idProduto` = (select `produto`.`idProduto` from `itempedido` group by `produto`.`idProduto` order by sum(`itempedido`.`quantidade`) desc)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `bestseller1122`
--

/*!50001 DROP VIEW IF EXISTS `bestseller1122`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `bestseller1122` AS select `produto`.`nome` AS `Produto`,`cliente`.`nome` AS `Cliente`,`pedido`.`dataPedido` AS `Data_Pedido` from (((`produto` join `itempedido` on((`produto`.`idProduto` = `itempedido`.`Produto_idProduto`))) join `pedido` on((`itempedido`.`Pedido_idPedido` = `pedido`.`idPedido`))) join `cliente` on((`pedido`.`Cliente_idCliente` = `cliente`.`idCliente`))) where (`produto`.`idProduto` = (select `produto`.`idProduto` from `itempedido` group by `produto`.`idProduto` order by sum(`itempedido`.`quantidade`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `bestseller112`
--

/*!50001 DROP VIEW IF EXISTS `bestseller112`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `bestseller112` AS select `produto`.`nome` AS `Produto`,`cliente`.`nome` AS `Cliente`,`pedido`.`dataPedido` AS `Data_Pedido` from (((`produto` join `itempedido` on((`produto`.`idProduto` = `itempedido`.`Produto_idProduto`))) join `pedido` on((`itempedido`.`Pedido_idPedido` = `pedido`.`idPedido`))) join `cliente` on((`pedido`.`Cliente_idCliente` = `cliente`.`idCliente`))) where (`produto`.`idProduto` = (select `produto`.`idProduto` from `itempedido` group by `produto`.`idProduto` order by sum(`itempedido`.`quantidade`) desc)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `pedidoatualizadoview123456`
--

/*!50001 DROP VIEW IF EXISTS `pedidoatualizadoview123456`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `pedidoatualizadoview123456` AS select `pedido`.`idPedido` AS `idPedido`,`produto`.`nome` AS `Produto`,sum((`itempedido`.`preco` * `itempedido`.`quantidade`)) AS `ValorTotal` from (`pedido` join (`itempedido` join `produto` on((`itempedido`.`Produto_idProduto` = `produto`.`idProduto`)))) where ((`pedido`.`idPedido` = 6) and (`itempedido`.`Pedido_idPedido` = `pedido`.`idPedido`)) limit 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `lastseller123`
--

/*!50001 DROP VIEW IF EXISTS `lastseller123`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `lastseller123` AS select `produto`.`idProduto` AS `idProduto`,`produto`.`nome` AS `nome`,`produto`.`descricao` AS `descricao`,sum(`itempedido`.`quantidade`) AS `total_vendido` from ((`pedido` join `itempedido` on((`pedido`.`idPedido` = `itempedido`.`Pedido_idPedido`))) join `produto` on((`itempedido`.`Produto_idProduto` = `produto`.`idProduto`))) group by `produto`.`nome` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `pedidoatualizadoview1234`
--

/*!50001 DROP VIEW IF EXISTS `pedidoatualizadoview1234`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `pedidoatualizadoview1234` AS select `pedido`.`idPedido` AS `idPedido`,sum((`itempedido`.`preco` * `itempedido`.`quantidade`)) AS `ValorTotal` from (`pedido` join (`itempedido` join `produto` on((`itempedido`.`Produto_idProduto` = `produto`.`idProduto`)))) where ((`pedido`.`idPedido` = 1) and (`itempedido`.`Pedido_idPedido` = `pedido`.`idPedido`)) limit 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `lastseller1234`
--

/*!50001 DROP VIEW IF EXISTS `lastseller1234`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `lastseller1234` AS select `produto`.`nome` AS `nome`,sum(`itempedido`.`quantidade`) AS `total_vendido` from ((`pedido` join `itempedido` on((`pedido`.`idPedido` = `itempedido`.`Pedido_idPedido`))) join `produto` on((`itempedido`.`Produto_idProduto` = `produto`.`idProduto`))) group by `produto`.`nome` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `comprafalsa`
--

/*!50001 DROP VIEW IF EXISTS `comprafalsa`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `comprafalsa` AS select `produto`.`idProduto` AS `idProduto`,`produto`.`quantidadeStock` AS `quantidadeStock` from `produto` limit 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `pedidosaoano`
--

/*!50001 DROP VIEW IF EXISTS `pedidosaoano`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `pedidosaoano` AS select year(`pedido`.`dataPedido`) AS `year`,count(0) AS `quantidade` from `pedido` group by year(`pedido`.`dataPedido`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `lastseller12`
--

/*!50001 DROP VIEW IF EXISTS `lastseller12`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `lastseller12` AS select `produto`.`idProduto` AS `idProduto`,`produto`.`nome` AS `nome`,`produto`.`descricao` AS `descricao`,sum(`itempedido`.`quantidade`) AS `total_vendido` from ((`pedido` join `itempedido` on((`pedido`.`idPedido` = `itempedido`.`Pedido_idPedido`))) join `produto` on((`itempedido`.`Produto_idProduto` = `produto`.`idProduto`))) group by `produto`.`idProduto`,`produto`.`nome` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `lastseller1`
--

/*!50001 DROP VIEW IF EXISTS `lastseller1`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `lastseller1` AS select `produto`.`idProduto` AS `idProduto`,`produto`.`nome` AS `nome`,`produto`.`descricao` AS `descricao`,sum(`itempedido`.`quantidade`) AS `total_vendido` from ((`pedido` join `itempedido` on((`pedido`.`idPedido` = `itempedido`.`Pedido_idPedido`))) join `produto` on((`itempedido`.`Produto_idProduto` = `produto`.`idProduto`))) group by `produto`.`idProduto`,`produto`.`nome` order by max(`pedido`.`dataEntrega`) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `pedidosaoano2`
--

/*!50001 DROP VIEW IF EXISTS `pedidosaoano2`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `pedidosaoano2` AS select year(`pedido`.`dataPedido`) AS `Ano`,count(0) AS `quantidade` from `pedido` group by year(`pedido`.`dataPedido`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `pedidosaoano22`
--

/*!50001 DROP VIEW IF EXISTS `pedidosaoano22`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `pedidosaoano22` AS select year(`pedido`.`dataPedido`) AS `Ano`,count(0) AS `Vendas` from `pedido` group by year(`pedido`.`dataPedido`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `pedidoatualizado`
--

/*!50001 DROP VIEW IF EXISTS `pedidoatualizado`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `pedidoatualizado` AS select `pedido`.`idPedido` AS `idPedido`,`cliente`.`nome` AS `Cliente`,sum((`itempedido`.`preco` * `itempedido`.`quantidade`)) AS `ValorTotal` from (((`itempedido` join `produto` on((`itempedido`.`Produto_idProduto` = `produto`.`idProduto`))) join `pedido` on((`itempedido`.`Pedido_idPedido` = `pedido`.`idPedido`))) join `cliente` on((`pedido`.`Cliente_idCliente` = `cliente`.`idCliente`))) where ((`pedido`.`idPedido` = 6) and (`itempedido`.`Pedido_idPedido` = `pedido`.`idPedido`) and (`pedido`.`Cliente_idCliente` = `cliente`.`idCliente`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-28  4:46:14
